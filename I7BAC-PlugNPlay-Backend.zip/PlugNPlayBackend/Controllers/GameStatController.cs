﻿using Microsoft.AspNetCore.Mvc;

namespace PlugNPlayBackend.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class GameStatController : ControllerBase
    {
    }
}
