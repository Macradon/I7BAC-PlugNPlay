﻿namespace PlugNPlayBackend.Services.Interfaces
{
    public interface IGamestatService
    {
    }
}
