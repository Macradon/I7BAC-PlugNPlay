﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace PlugNPlayBackend.Services.Interfaces
{
    public interface IFriendlistService
    {
        public Task<List<string>> GetFriendlist(string username);
        public Task<List<string>> AddFriend(string username, string friendUsername);
        public Task<List<string>> RemoveFriend(string username, string friendUsername);
    }
}
