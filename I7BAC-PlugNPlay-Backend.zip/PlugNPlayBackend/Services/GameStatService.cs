﻿using PlugNPlayBackend.Services.Interfaces;

namespace PlugNPlayBackend.Services
{
    public class GameStatService : IGamestatService
    {
    }
}
