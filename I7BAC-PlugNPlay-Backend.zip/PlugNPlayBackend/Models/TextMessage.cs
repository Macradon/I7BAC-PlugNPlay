﻿namespace PlugNPlayBackend.Models
{
    public class TextMessage
    {
        public string Sender { get; set; }
        public string Message { get; set; }
    }
}
