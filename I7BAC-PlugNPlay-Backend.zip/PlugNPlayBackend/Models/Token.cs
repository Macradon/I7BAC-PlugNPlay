﻿namespace PlugNPlayBackend.Models
{
    public class Token
    {
        public Token(string username)
        {
            JsonWebToken = "Token response not implemented";
        }

        public string JsonWebToken { get; set; }
    }
}
