export interface NimMove {
  player: number;
  amountTaken: number;
}
