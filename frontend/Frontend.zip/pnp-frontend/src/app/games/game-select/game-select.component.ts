import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-game-select',
  templateUrl: './game-select.component.html',
  styleUrls: ['./game-select.component.scss']
})
export class GameSelectComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
