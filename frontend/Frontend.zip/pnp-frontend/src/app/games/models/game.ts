export interface Game {
  _id: string;
  Name: string;
  Link: string;
  Pic: string;
  Desc: string;
  Players: number;
}
