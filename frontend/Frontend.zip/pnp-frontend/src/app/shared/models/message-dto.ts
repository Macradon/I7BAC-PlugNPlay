export interface MessageDTO {
  Sender: string;
  Message: string;
}
