export interface ChatMessage {
  username: string;
  message: string;
}
