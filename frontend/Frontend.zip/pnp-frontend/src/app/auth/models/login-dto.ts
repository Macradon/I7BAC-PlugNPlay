export interface LoginDTO {
  Username: string;
  Password: string;
}
