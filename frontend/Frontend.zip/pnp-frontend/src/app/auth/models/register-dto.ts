export interface RegisterDTO {
  Username: string;
  Password: string;
  Email: string;
}
